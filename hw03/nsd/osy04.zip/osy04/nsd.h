#ifndef __NSD_H__
#define __NSD_H__

extern int nsd(int a, int b);  // nejvetsi spolecny delitel cisel a,b

#endif
