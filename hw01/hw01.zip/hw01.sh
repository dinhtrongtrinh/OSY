#!/bin/bash
Zflag=0
files_to_archive=()

while getopts "hz" opt; do
    case $opt in
        h)
            
            echo "Použití: $0 [-h] [-z] < input_file>"
echo ""
echo "Popis:"
echo "  Skript čte řádky ze standardního vstupu a podle obsahu zpracovává cesty."
echo ""
echo "Přepínače:"
echo "  -h      Zobrazí tuto nápovědu a ukončí skript."
echo "  -z      Zapne speciální režim (příklad použití, upřesni podle potřeby)."
echo ""
echo "Formát vstupu:"
echo "  Řádek musí začínat 'PATH', 'FILE', 'DIR' nebo 'LINK', následovaný cestou."
echo ""
echo "Příklad použití:"
echo "  $0 -z < seznam_cest.txt"

            exit 0;;
        z)
            Zflag=1
            ;;
        *)
            #nejaka chyba
            exit 1;;
    esac
done

while IFS= read -r line; do
    if [[ $line == PATH* ]]; then
        cesta="${line#PATH}"    # odstraní PATH
        cesta="${cesta#"${cesta%%[![:space:]]*}"}" # odstraní mezery na začátku (tady vysvetlit, jak to funguje)
        # Urcit, jestli to je adresa ci soubor
        if [[ -d "$cesta" ]]; then
            #Vypsat soubory v adresari
            ls -1 "$cesta"
        elif [[ -L "$cesta" ]]; then
            cil=$(readlink "$cesta")            # vysvetlit co je LINK
            echo "${cesta} ${cil}"
        elif [[ -f "$cesta" ]]; then
            num_line=$(wc -l < "$cesta")
            echo "$num_line"
            first_line=$(head -n 1 "$cesta")
            echo "$first_line"
            files_to_archive+=("$cesta")
        else
            exit 1
            
        fi

    fi
done
if [[ $Zflag -eq 1 && ${#files_to_archive[@]} -gt 0 ]]; then
    tar czf output.tgz "${files_to_archive[@]}"
fi
exit 0
